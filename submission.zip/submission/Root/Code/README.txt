QUIZZIT - Quiz Master Application
A Flask-based platform for creating, managing, and attempting quizzes

Features
User Authentication
Secure login/registration for students & admins
Role-based access (Admin/User)
Quiz Management
    . Create/Edit/Delete Subjects & Chapters
    . Build quizzes with MCQ questions (single correct answer)
    . Set time limits and quiz schedules

User Features
    . Attempt quizzes with real-time timer
    . View attempt history and scores
    . Track progress through visual charts

Admin Features
    . CRUD operations for subjects/chapters/quizzes
    . Manage user accounts and permissions

View detailed analytics:
    . Quiz performance metrics
    . User participation statistics

Additional Features
    . Automatic scoring system
    . Quiz attempt time tracking
    . Responsive UI with Bootstrap

Technologies Used
1. Backend: Python Flask
2. Database: SQLite (with SQLAlchemy ORM)
3. Frontend: Jinja2 templates + Bootstrap
4. Visualization: Plotly for analytics
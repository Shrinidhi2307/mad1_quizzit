from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from models import db, User, Subject, Chapter, Quiz, Question, Score
from datetime import datetime

main = Blueprint('main', __name__)

@main.route('/')
def home():
    return redirect(url_for('main.login'))

@main.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.password == password:
            session['user_id'] = user.id
            if user.is_admin:
                return redirect(url_for('main.admin_dashboard'))
            return redirect(url_for('main.user_dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@main.route('/user/dashboard')
def user_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('main.login'))
    user = User.query.get(session['user_id'])
    subjects = Subject.query.all()
    return render_template('user_dashboard.html', user=user, subjects=subjects)

@main.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('main.login'))
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return redirect(url_for('main.user_dashboard'))
    subjects = Subject.query.all()
    return render_template('admin_dashboard.html', subjects=subjects)

@main.route('/quiz/<int:quiz_id>')
def take_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    return render_template('take_quiz.html', quiz=quiz)

@main.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('main.home'))
